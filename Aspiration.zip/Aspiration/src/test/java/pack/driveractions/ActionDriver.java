package pack.driveractions;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Workbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;


public class ActionDriver {

	protected static HashMap<String, WebDriver> driverObjMap = new HashMap<String, WebDriver>();
	protected static WebDriver driver;
	public static Properties CONFIG = null;
	public static Properties prop = null;
	public static Logger APP_LOGS = null;
	public static boolean isInitialized = false;

	// public static org.slf4j.Logger logger =
	// LoggerFactory.getLogger(MEB_Tab.class);
	public static File file = null;
	public static FileInputStream fileInput = null;

	private static Properties TestProperties = null;
	private static FileInputStream fisTestConfig = null;

	@BeforeSuite
	public void setup() throws IOException {
		try {

			file = new File(System.getProperty("user.dir") + "\\Data\\testdata.properties");
			fileInput = new FileInputStream(file);
			prop = new Properties();
			prop.load(fileInput);
		} catch (FileNotFoundException e) {
			e.getMessage();

		} catch (IOException e1) {
			// logger.error(e1.getMessage());
			throw e1;

		}
		System.setProperty("webdriver.chrome.driver",
				System.getProperty("user.dir") +"\\Aspiration\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.navigate().to(prop.getProperty("URL"));
		driverObjMap.put(getClass().getName(), driver);
		driver.manage().window().maximize();

	}

	public static WebDriver gerDriverDetails(String className) {
		return driverObjMap.get(className);
	}

	public static HashMap<String, WebDriver> gerDriverObjMap() {
		return driverObjMap;
	}

	@AfterSuite

	public void quitDriver() {
		if (gerDriverObjMap().get(getClass().getName()) != null) {
			gerDriverObjMap().get(getClass().getName()).quit();
			gerDriverObjMap().remove(getClass().getName());
			System.out.println("driver for class : " + getClass().getName() + "is closed");
		}
	}
//wait until element located
	public WebElement waitTillElementLocated(WebElement webElement) {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		WebElement elementloaded = wait.until(ExpectedConditions.elementToBeClickable(webElement));
		return elementloaded;
	}
//click element by using Actions class
	public void actionsClick(WebElement element) {

		Actions action = new Actions(driver);
		action.moveToElement(element).click().perform();
	}
	public void waitforelement() {
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.MINUTES);
		/*WebDriverWait wait = new WebDriverWait(driver, 200);
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("theImg")));*/

	}

	//click element and highlight while executing
	public static void clickElement(WebElement e) throws Exception {

		for (int i = 0; i <= 15; i++) {
			try {
				e.click();
				break;

			} catch (Exception e1) {
				if (i == 15) {
					throw e1;

				} else {
					Thread.sleep(1000);
					System.out.println(e1.getMessage());
				}
			}
		}
	}

	// Java script click
	public void safeJavaScriptClick(WebElement element) throws Exception {
		try {
			if (element.isEnabled() && element.isDisplayed()) {
				System.out.println("Clicking on element with using java script click");

				((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
			} else {
				System.out.println("Unable to click on element");
			}
		} catch (StaleElementReferenceException e) {
			System.out.println("Element is not attached to the page document " + e.getStackTrace());
		} catch (NoSuchElementException e) {
			System.out.println("Element was not found in DOM " + e.getStackTrace());
		} catch (Exception e) {
			System.out.println("Unable to click on element " + e.getStackTrace());
		}
	}

	public static void click(WebElement e) throws Exception {
		Thread.sleep(1000);
		for (int i = 0; i <= 25; i++) {
			try {
				e.click();
				break;

			} catch (Exception e1) {
				if (i == 25) {
					throw e1;

				} else {
					Thread.sleep(1000);
					System.out.println(e1.getMessage());
				}
			}
		}
		String color = backgroundColor(e);
		changeColor(e, "green");
		Thread.sleep(2000);
		changeColor(e, color);
	}

	private static void changeColor(WebElement element, String color) {

		JavascriptExecutor jsDriver = (JavascriptExecutor) driver;
		String jsQuery = String.format("arguments[0].style.backgroundColor='%s'", color);

		jsDriver.executeScript(jsQuery, element);
	}

	private static String backgroundColor(WebElement e) {
		JavascriptExecutor jsDriver = (JavascriptExecutor) driver;
		String jsQuery = "return arguments[0].style.backgroundColor";

		return (String) jsDriver.executeScript(jsQuery, e);

	}

	public static void waitForVisible(WebElement locator) throws Exception {
		Thread.sleep(1000);
		for (int i = 0; i <= 40; i++) {
			try {
				locator.isDisplayed();
				break;

			} catch (Exception e) {
				if (i == 40) {
					throw e;

				} else {
					Thread.sleep(1000);

				}
			}
		}
	}
	// highlight the elements
	/*
	 * protected static void highlight(WebElement e) throws InterruptedException
	 * { String color = backgroundColor(e); changeColor(e, "green");
	 * Thread.sleep(2000); changeColor(e, color); }
	 * 
	 * private static void changeColor(WebElement element, String color) {
	 * 
	 * JavascriptExecutor jsDriver = (JavascriptExecutor)driver; String jsQuery
	 * = String.format("arguments[0].style.backgroundColor='%s'", color);
	 * 
	 * jsDriver.executeScript(jsQuery, element); }
	 * 
	 * private static String backgroundColor(WebElement e) { JavascriptExecutor
	 * jsDriver = (JavascriptExecutor)driver; String jsQuery =
	 * "return arguments[0].style.backgroundColor";
	 * 
	 * return (String)jsDriver.executeScript(jsQuery, e); }
	 */

	public void waitforloadingDisable() {

		WebDriverWait wait = new WebDriverWait(driver, 200);
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("theImg")));

	}

	public static void waitForVisibleDropdown(List<WebElement> elements) throws Exception {
		Thread.sleep(1000);
		for (int i = 0; i <= 25; i++) {
			try {
				if (elements.size() != 0) {
					break;
				} else {
					throw new Exception("list size is 0");
				}

			} catch (Exception e) {
				if (i == 25) {
					throw e;

				} else {
					Thread.sleep(1000);
					elements = elements;
				}
			}

		}
	}

	public void scrollElementToViewPoint(WebElement element) throws InterruptedException {
		Actions actions = new Actions(driver);
		actions.moveToElement(element).build().perform();
		Thread.sleep(5000);
		// waitTillPageLoaded(driver);
		// Thread.sleep(3000);
	}

	// public static void waitTillPageLoaded(WebDriver driver) {
	// ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>()
	// {
	// public Boolean apply(WebDriver driver) {
	// return ((JavascriptExecutor) driver).executeScript("return
	// document.readyState").equals("complete");
	// }
	// };
	//
	// Wait<WebDriver> wait = new WebDriverWait(driver, 30);
	// try {
	// wait.until(expectation);
	// } catch (Throwable error) {
	//
	// }
	// }

	// high liht the elemnt while pass the data in to input box

	public static void type(WebElement textbox, String inputdata) throws Exception {
		Thread.sleep(1000);
		for (int i = 0; i <= 15; i++) {
			try {
				textbox.clear();
				textbox.sendKeys(inputdata);
				break;

			} catch (Exception e) {
				if (i == 15) {
					throw e;

				} else {
					Thread.sleep(1000);
				}
			}
		}

		String color = backgroundColor(textbox);
		changeColor(textbox, "green");
		Thread.sleep(2000);
		changeColor(textbox, color);
	}

	// public static String readingdata(int sheetno, int rownum, int colnum)
	// throws Exception {
	// File file = new File(System.getProperty("user.dir") +
	// "\\src\\test\\resources\\Vehicle_Details_Data.xlsx");
	// FileInputStream fileInputStream = new FileInputStream(file);
	// XSSFWorkbook hssfWorkbook = new XSSFWorkbook(fileInputStream);
	// XSSFSheet sheet = hssfWorkbook.getSheetAt(sheetno);
	// XSSFCell cell = sheet.getRow(rownum).getCell(colnum);
	// DataFormatter df = new DataFormatter();
	// String data = df.formatCellValue(cell);
	//
	// return data;
	//
	// }

	public static void ulselect(List<WebElement> li) throws Exception {
		Thread.sleep(1000);
		int i = 0;
		for (WebElement name : li) {
			if (name.isDisplayed()) {
				if (i >= 1) {
					// click(name);
					name.click();
					break;
				}
			}
			i++;
		}
	}

	public boolean isAlertPresent() {
		try {
			driver.switchTo().alert().accept();
			return true;
		} // try
		catch (NoAlertPresentException Ex) {
			// logger.info("No alert present");
			return false;

		} // catch
	} // isAlertPresent()

	public void javascriptexecutorClick(WebElement element) throws Exception {
		Thread.sleep(1000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", element);

	}

	public void javascriptexecutorScrollDown() throws Exception {
		Thread.sleep(1000);
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0,250)");

	}

	public void javascriptexecutorScrollUp() throws Exception {
		Thread.sleep(1000);
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0,-500)", "");

	}

	public static void takeSnapShot(WebDriver webdriver, String fileWithPath) throws Exception {

		// Convert web driver object to TakeScreenshot

		TakesScreenshot scrShot = ((TakesScreenshot) webdriver);

		// Call getScreenshotAs method to create image file

		File SrcFile = scrShot.getScreenshotAs(OutputType.FILE);

		// Move image file to new destination

		File DestFile = new File(fileWithPath);

		// Copy file at destination

		FileUtils.copyFile(SrcFile, DestFile);

	}

	/*// read data from excel
	public String[][] getExcelData(String fileName, String sheetName) {
		String[][] arrayExcelData = null;
		try {
			FileInputStream fs = new FileInputStream(fileName);
			Workbook wb = Workbook.getWorkbook(fs);
			Sheet sh = wb.getSheet(sheetName);

			int totalNoOfCols = sh.getColumns();
			int totalNoOfRows = sh.getRows();

			arrayExcelData = new String[totalNoOfRows - 1][totalNoOfCols];

			for (int i = 1; i < totalNoOfRows; i++) {

				for (int j = 0; j < totalNoOfCols; j++) {
					arrayExcelData[i - 1][j] = sh.getCell(j, i).getContents();
				}

			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
			e.printStackTrace();
		} catch (BiffException e) {
			e.printStackTrace();
		}
		return arrayExcelData;
	}

	public String readExcel(int row, int col) throws BiffException, IOException {

		String FilePath = "C:\\Users\\AlluriA\\Desktop\\Ballard\\Ballard\\MEBATESTDATA.xls";
		FileInputStream fs = new FileInputStream(FilePath);
		Workbook wb = Workbook.getWorkbook(fs);

		// TO get the access to the sheet
		Sheet sh = wb.getSheet("Sheet1");

		// To get the number of rows present in sheet
		int totalNoOfRows = sh.getRows();

		// To get the number of columns present in sheet
		int totalNoOfCols = sh.getColumns();

		return sh.getCell(col, row).getContents();
	}

	// send email to stake holders
	public static void sendEmail(String subject, String message) {

		TestProperties = new Properties();
		try {
			fisTestConfig = new FileInputStream(System.getProperty("user.dir") + "\\Data\\testdata_MEBA.properties");

			TestProperties.load(fisTestConfig);

			String host = TestProperties.getProperty("host").trim();
			String port = TestProperties.getProperty("port").trim();
			final String mailFrom = TestProperties.getProperty("mailFrom").trim();
			final String password = TestProperties.getProperty("password").trim();

			String[] to = TestProperties.getProperty("to").trim().split(",");
			String[] cc = {};
			String ccString = TestProperties.getProperty("cc").trim();
			if (ccString.length() > 0) {
				cc = ccString.split(",");
			}

			String[] bcc = {};
			String bccString = TestProperties.getProperty("bcc").trim();
			if (bccString.length() > 0) {
				bcc = bccString.split(",");
			}

			String[] attachFilesPaths = TestProperties.getProperty("attachFilesPaths").trim().split(",");

			Properties properties = new Properties();
			properties.put("mail.smtp.host", host);
			properties.put("mail.smtp.port", port);
			properties.put("mail.smtp.auth", "true");
			properties.put("mail.smtp.starttls.enable", "true");
			properties.put("mail.user", mailFrom);
			properties.put("mail.password", password);

			// creates a new session with an authenticator
			Authenticator auth = new Authenticator() {
				public PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(mailFrom, password);
				}
			};
			Session session = Session.getInstance(properties, auth);

			Message msg = new MimeMessage(session);

			msg.setFrom(new InternetAddress(mailFrom));

			for (int i = 0; i < to.length; i++) {
				msg.addRecipient(Message.RecipientType.TO, new InternetAddress(to[i]));
			}

			for (int i = 0; i < cc.length; i++) {
				msg.addRecipient(Message.RecipientType.CC, new InternetAddress(cc[i]));
			}

			for (int i = 0; i < bcc.length; i++) {
				msg.addRecipient(Message.RecipientType.BCC, new InternetAddress(bcc[i]));
			}

			msg.setSubject(subject);
			msg.setSentDate(new Date());

			// creates message part
			MimeBodyPart messageBodyPart = new MimeBodyPart();
			messageBodyPart.setContent(message, "text/html");

			// creates multi-part
			Multipart multipart = new MimeMultipart();
			multipart.addBodyPart(messageBodyPart);

			// adds attachments
			if (attachFilesPaths != null && attachFilesPaths.length > 0) {
				for (String filePath : attachFilesPaths) {
					MimeBodyPart attachPart = new MimeBodyPart();

					try {
						attachPart.attachFile(filePath);
					} catch (IOException ex) {
						ex.printStackTrace();
					}

					multipart.addBodyPart(attachPart);
				}
			}

			msg.setContent(multipart);

			// sends the e-mail
			Transport.send(msg);
			System.out.println("Message after sending email!");
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (MessagingException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}
	}*/
}
