package pack.testcases;

import pack.driveractions.ActionDriver;
import pack.pageobjects.AspirationProductsClass;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import pack.driveractions.ActionDriver;


public class AspirationRunClass extends ActionDriver{
	@BeforeSuite
	public void setup() throws IOException {
		try {

			file = new File(System.getProperty("user.dir") + "\\Data\\testdata.properties");
			fileInput = new FileInputStream(file);
			prop = new Properties();
			prop.load(fileInput);
		} catch (FileNotFoundException e) {
			e.getMessage();

		} catch (IOException e1) {
			// logger.error(e1.getMessage());
			throw e1;

		}
		System.setProperty("webdriver.chrome.driver",
				System.getProperty("user.dir") +"\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.navigate().to(prop.getProperty("URL"));
		driverObjMap.put(getClass().getName(), driver);
		driver.manage().window().maximize();

	}
	@Test
	public void SpendandSaveLink() throws Exception
	{
		AspirationProductsClass page1=new AspirationProductsClass(driver);
		page1.Get_Aspiration();
		page1.Get_Aspiration_Plus();
	}



}
