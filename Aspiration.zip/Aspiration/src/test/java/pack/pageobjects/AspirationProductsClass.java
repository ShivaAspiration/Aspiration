package pack.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import pack.driveractions.ActionDriver;

public class AspirationProductsClass extends ActionDriver {
	WebDriver driver;

	@FindBy(xpath = "//header/ul[1]/li[1]/a[1]")
	WebElement SpendandSave;
	
	@FindBy(xpath = "//body/div[1]/div[1]/main[1]/div[1]/div[1]/spend-save-plans[1]/div[1]/div[1]/div[1]/div[2]/div[2]/button[1]")
	WebElement Productbuttontitle;
	
	@FindBy(xpath = "//button[contains(text(),'Get Aspiration Plus')]")
	WebElement GetAspirationPlusbutton;
	
	@FindBy(xpath = "//body[1]/div[1]/div[1]/div[1]/div[1]/button[1]")
	WebElement closeicon;
	
	@FindBy(xpath = "//input[@id='join-waitlist-input']")
	WebElement Emailfield;

	@FindBy(xpath = "//*[@id='pageContainer']/header/nav/ul/li[4]")
	WebElement Myassignmentsection;

	public AspirationProductsClass(WebDriver driver) {

		this.driver = driver;

		PageFactory.initElements(driver, this);

	}

	public void Get_Aspiration() throws Exception {
		// TODO Auto-generated method stub
		WebDriverWait wait = new WebDriverWait(driver, 5);
		clickElement(SpendandSave);
		//wait();
		Thread.sleep(2000);
		WebElement GetAspiration=wait.until(ExpectedConditions.elementToBeClickable(Productbuttontitle));
		if(GetAspiration.isDisplayed()){
			System.out.println("GetAspiration button is displayed as--->" +GetAspiration.getText());
			clickElement(Productbuttontitle);
		}else{
			System.out.println("GetAspiration button is not displayed");

		}
		
		Thread.sleep(2000);
		WebElement Emailfieldverification=wait.until(ExpectedConditions.elementToBeClickable(Emailfield));
		if(Emailfieldverification.isDisplayed()){
			System.out.println("Email field is displayed as--->" +Emailfield.getText());
			Thread.sleep(2000);
			clickElement(closeicon);
		}else{
			System.out.println("Email field is not displayed");

		}
		

	}
	
	
	public void Get_Aspiration_Plus() throws Exception {
		// TODO Auto-generated method stub
		WebDriverWait wait = new WebDriverWait(driver, 5);
		//wait();
		Thread.sleep(2000);
		WebElement GetAspirationplus=wait.until(ExpectedConditions.elementToBeClickable(GetAspirationPlusbutton));
		if(GetAspirationplus.isDisplayed()){
			System.out.println("Get Aspiration plus button is displayed as--->" +GetAspirationplus.getText());
			clickElement(GetAspirationPlusbutton);
		}else{
			System.out.println("Get Aspiration plus button is not displayed");

		}
		String yearlyplan = driver
				.findElement(
						By.xpath("//body[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/p[1]"))
				.getText();
		Thread.sleep(2000);
		Assert.assertEquals(yearlyplan, "$ paid once yearly");
		System.out.println(yearlyplan);
		String monthlyplan = driver
				.findElement(
						By.xpath("//body[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[2]/p[1]"))
				.getText();
		Assert.assertEquals(monthlyplan, "$7.99 paid monthly");
		System.out.println(monthlyplan);
		Thread.sleep(2000);
		clickElement(closeicon);
		
		
	}
}
